document.addEventListener('DOMContentLoaded', function() {
  console.log('Project HUT80 is ready!');
});